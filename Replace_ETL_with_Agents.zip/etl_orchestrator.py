import os
import json
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
from file_reader_agent import FileReaderAgent
from data_transformation_agent import DataTransformationAgent

class ETLOrchestrator:
    """
    Main ETL orchestrator that coordinates file reading and data transformation agents.
    """
    
    def __init__(self, base_directory: str = None, google_api_key: str = None, llm_provider: str = "google", llm_model: str = "gemini-2.0-flash-exp"):
        self.base_directory = base_directory or os.getcwd()
        self.file_reader = FileReaderAgent(base_directory)
        self.transformer = DataTransformationAgent(
            llm_api_key=google_api_key,
            llm_provider=llm_provider,
            llm_model=llm_model
        )
        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self.pipeline_history = []
    
    def run_pipeline(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run a complete ETL pipeline based on configuration.
        
        Args:
            config: ETL configuration dictionary
            
        Returns:
            Dictionary containing pipeline results and metadata
        """
        pipeline_start = datetime.now()
        
        try:
            # Extract configuration
            input_config = config.get('input', {})
            transformation_config = config.get('transformations', [])
            output_config = config.get('output', {})
            
            # Step 1: Read input files
            read_results = self._read_input_files(input_config)
            
            if not read_results['success']:
                return read_results
            
            # Step 2: Apply transformations
            transform_results = self._apply_transformations(
                read_results['data'], 
                transformation_config
            )
            
            if not transform_results['success']:
                return transform_results
            
            # Step 3: Save output if configured
            output_results = self._save_output(
                transform_results['data'], 
                output_config
            )
            
            pipeline_end = datetime.now()
            execution_time = (pipeline_end - pipeline_start).total_seconds()
            
            # Record pipeline execution
            pipeline_record = {
                'pipeline_id': config.get('name', 'unnamed_pipeline'),
                'start_time': pipeline_start.isoformat(),
                'end_time': pipeline_end.isoformat(),
                'execution_time_seconds': execution_time,
                'input_files': input_config.get('files', []),
                'transformations_count': len(transformation_config),
                'success': True,
                'output_path': output_config.get('path'),
                'records_processed': self._count_records(transform_results['data'])
            }
            
            self.pipeline_history.append(pipeline_record)
            
            return {
                'success': True,
                'pipeline_record': pipeline_record,
                'data': transform_results['data'],
                'read_results': read_results,
                'transform_results': transform_results,
                'output_results': output_results,
                'execution_time': execution_time
            }
            
        except Exception as e:
            self.logger.error(f"Pipeline execution failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'execution_time': (datetime.now() - pipeline_start).total_seconds()
            }
    
    def _read_input_files(self, input_config: Dict[str, Any]) -> Dict[str, Any]:
        """Read input files based on configuration"""
        files = input_config.get('files', [])
        batch_mode = input_config.get('batch', False)
        read_params = input_config.get('params', {})
        
        if batch_mode:
            results = self.file_reader.batch_read(files, **read_params)
            successful_reads = [r for r in results if r['success']]
            failed_reads = [r for r in results if not r['success']]
            
            if failed_reads:
                self.logger.warning(f"Failed to read {len(failed_reads)} files")
            
            # Combine data from all successful reads
            combined_data = self._combine_data([r['data'] for r in successful_reads])
            
            return {
                'success': len(successful_reads) > 0,
                'data': combined_data,
                'read_results': results,
                'successful_reads': len(successful_reads),
                'failed_reads': len(failed_reads)
            }
        else:
            # Single file mode
            if len(files) != 1:
                raise ValueError("Single file mode requires exactly one file")
            
            result = self.file_reader.read_file(files[0], **read_params)
            return {
                'success': result['success'],
                'data': result['data'] if result['success'] else None,
                'error': result['error'],
                'metadata': result['metadata']
            }
    
    def _apply_transformations(self, data: Any, transformations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Apply transformations to data"""
        return self.transformer.transform(data, transformations)
    
    def _save_output(self, data: Any, output_config: Dict[str, Any]) -> Dict[str, Any]:
        """Save transformed data to output"""
        if not output_config.get('path'):
            return {'success': True, 'message': 'No output path specified'}
        
        try:
            output_path = output_config['path']
            format_type = output_config.get('format', 'csv')
            params = output_config.get('params', {})
            
            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            if format_type == 'csv':
                if hasattr(data, 'to_csv'):
                    # Remove index from params if it exists to avoid duplicate argument
                    csv_params = params.copy()
                    csv_params.pop('index', None)
                    data.to_csv(output_path, index=False, **csv_params)
                else:
                    with open(output_path, 'w') as f:
                        json.dump(data, f, indent=2)
            elif format_type == 'json':
                with open(output_path, 'w') as f:
                    json.dump(data, f, indent=2, default=str)
            elif format_type == 'excel':
                if hasattr(data, 'to_excel'):
                    # Remove index from params if it exists to avoid duplicate argument
                    excel_params = params.copy()
                    excel_params.pop('index', None)
                    data.to_excel(output_path, index=False, **excel_params)
            else:
                raise ValueError(f"Unsupported output format: {format_type}")
            
            return {
                'success': True,
                'output_path': output_path,
                'format': format_type,
                'records_written': self._count_records(data)
            }
            
        except Exception as e:
            self.logger.error(f"Failed to save output: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _combine_data(self, data_list: List[Any]) -> Any:
        """Combine data from multiple sources"""
        if not data_list:
            return None
        
        # If all items are DataFrames, concatenate them
        if all(hasattr(item, 'concat') for item in data_list):
            import pandas as pd
            return pd.concat(data_list, ignore_index=True)
        
        # If all items are lists, extend them
        elif all(isinstance(item, list) for item in data_list):
            combined = []
            for item in data_list:
                combined.extend(item)
            return combined
        
        # If all items are dicts, merge them
        elif all(isinstance(item, dict) for item in data_list):
            combined = {}
            for item in data_list:
                combined.update(item)
            return combined
        
        # Handle mixed data types - convert everything to a common format
        else:
            # Convert DataFrames to lists of dictionaries
            normalized_data = []
            for item in data_list:
                if hasattr(item, 'to_dict'):  # DataFrame
                    normalized_data.extend(item.to_dict('records'))
                elif isinstance(item, list):
                    normalized_data.extend(item)
                elif isinstance(item, dict):
                    normalized_data.append(item)
                else:
                    # For other types, wrap in a dict
                    normalized_data.append({'value': item})
            
            return normalized_data
    
    def _count_records(self, data: Any) -> int:
        """Count records in data"""
        if hasattr(data, '__len__'):
            return len(data)
        elif hasattr(data, 'shape'):
            return data.shape[0]
        else:
            return 1
    
    def get_pipeline_history(self) -> List[Dict[str, Any]]:
        """Get history of all pipeline executions"""
        return self.pipeline_history
    
    def save_pipeline_config(self, config: Dict[str, Any], config_path: str):
        """Save pipeline configuration to file"""
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
    
    def load_pipeline_config(self, config_path: str) -> Dict[str, Any]:
        """Load pipeline configuration from file"""
        with open(config_path, 'r') as f:
            return json.load(f)
    
    def create_sample_config(self) -> Dict[str, Any]:
        """Create a sample ETL configuration"""
        return {
            "name": "sample_pipeline",
            "description": "Sample ETL pipeline configuration",
            "input": {
                "files": ["data.csv"],
                "batch": False,
                "params": {
                    "encoding": "utf-8"
                }
            },
            "transformations": [
                {
                    "type": "trim_whitespace",
                    "params": {}
                },
                {
                    "type": "remove_duplicates",
                    "params": {
                        "keep": "first"
                    }
                },
                {
                    "type": "select_columns",
                    "params": {
                        "columns": ["name", "email", "age"]
                    }
                },
                {
                    "type": "convert_types",
                    "params": {
                        "type_mapping": {
                            "age": "int",
                            "created_date": "datetime"
                        }
                    }
                }
            ],
            "output": {
                "path": "output/transformed_data.csv",
                "format": "csv",
                "params": {
                    "index": False
                }
            }
        }
