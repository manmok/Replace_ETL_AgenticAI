import os
import json
import requests
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import google.generativeai as genai

class LLMTransformationAgent:
    """
    Agent for LLM-based data transformations.
    Supports various LLM providers and prompt-based data conversion.
    """
    
    def __init__(self, api_key: str = None, provider: str = "google", model: str = "gemini-2.0-flash-exp"):
        self.api_key = api_key or os.getenv("GOOGLE_API_KEY")
        self.provider = provider
        self.model = model
        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self.transformation_history = []
        
        # Initialize Gemini client if using Google
        if provider == "google":
            genai.configure(api_key=self.api_key)
            self.client = genai.GenerativeModel(model)
    
    def transform_with_llm(self, data: Any, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Transform data using LLM based on input prompt.
        
        Args:
            data: Input data to transform
            prompt: Instruction prompt for the LLM
            **kwargs: Additional parameters (temperature, max_tokens, etc.)
            
        Returns:
            Dictionary containing transformed data and metadata
        """
        try:
            # Prepare data for LLM
            data_str = self._prepare_data_for_llm(data)
            
            # Create full prompt
            full_prompt = f"""
{prompt}

Data to transform:
{data_str}

Please return the result in JSON format.
"""
            
            # Call LLM
            response = self._call_llm(full_prompt, **kwargs)
            
            # Parse response
            transformed_data = self._parse_llm_response(response)
            
            # Record transformation
            transformation_record = {
                'type': 'llm_transformation',
                'prompt': prompt,
                'provider': self.provider,
                'model': self.model,
                'timestamp': datetime.now().isoformat(),
                'original_shape': self._get_shape(data),
                'transformed_shape': self._get_shape(transformed_data)
            }
            
            self.transformation_history.append(transformation_record)
            
            return {
                'data': transformed_data,
                'success': True,
                'error': None,
                'transformation_record': transformation_record
            }
            
        except Exception as e:
            self.logger.error(f"LLM transformation failed: {str(e)}")
            return {
                'data': data,
                'success': False,
                'error': str(e),
                'transformation_record': None
            }
    
    def _prepare_data_for_llm(self, data: Any) -> str:
        """Prepare data in a format suitable for LLM processing"""
        if hasattr(data, 'to_json'):  # pandas DataFrame
            return data.to_json(orient='records', indent=2)
        elif isinstance(data, (list, tuple)):
            return json.dumps(data, indent=2, default=str)
        elif isinstance(data, dict):
            return json.dumps(data, indent=2, default=str)
        else:
            return str(data)
    
    def _call_llm(self, prompt: str, **kwargs) -> str:
        """Call the LLM API"""
        if self.provider == "google":
            return self._call_gemini(prompt, **kwargs)
        elif self.provider == "openai":
            return self._call_openai(prompt, **kwargs)
        elif self.provider == "anthropic":
            return self._call_anthropic(prompt, **kwargs)
        else:
            raise ValueError(f"Unsupported LLM provider: {self.provider}")
    
    def _call_gemini(self, prompt: str, **kwargs) -> str:
        """Call Google Gemini API"""
        if not self.api_key:
            raise ValueError("Google API key is required. Set GOOGLE_API_KEY environment variable or pass api_key parameter.")
        
        try:
            # Configure generation parameters
            generation_config = {
                "temperature": kwargs.get('temperature', 0.3),
                "max_output_tokens": kwargs.get('max_tokens', 2000),
            }
            
            # Generate response
            response = self.client.generate_content(
                prompt,
                generation_config=generation_config
            )
            
            return response.text
        except Exception as e:
            raise Exception(f"Gemini API call failed: {str(e)}")
    
    def _call_openai(self, prompt: str, **kwargs) -> str:
        """Call OpenAI API"""
        import openai
        
        if not self.api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable or pass api_key parameter.")
        
        client = openai.OpenAI(api_key=self.api_key)
        
        response = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a data transformation assistant. Always respond with valid JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=kwargs.get('temperature', 0.3),
            max_tokens=kwargs.get('max_tokens', 2000)
        )
        
        return response.choices[0].message.content
    
    def _call_anthropic(self, prompt: str, **kwargs) -> str:
        """Call Anthropic Claude API"""
        if not self.api_key:
            raise ValueError("Anthropic API key is required. Set ANTHROPIC_API_KEY environment variable.")
        
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
        
        data = {
            "model": self.model,
            "max_tokens": kwargs.get('max_tokens', 2000),
            "temperature": kwargs.get('temperature', 0.3),
            "messages": [
                {"role": "user", "content": prompt}
            ]
        }
        
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=data
        )
        
        response.raise_for_status()
        return response.json()["content"][0]["text"]
    
    def _parse_llm_response(self, response: str) -> Any:
        """Parse LLM response and return structured data"""
        try:
            # Try to parse as JSON first
            return json.loads(response)
        except json.JSONDecodeError:
            # If not valid JSON, try to extract JSON from the response
            import re
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            else:
                # Return as string if no JSON found
                return response
    
    def _get_shape(self, data: Any) -> tuple:
        """Get shape of data"""
        if hasattr(data, 'shape'):
            return data.shape
        elif hasattr(data, '__len__'):
            return (len(data),)
        elif isinstance(data, dict):
            return (len(data),)
        else:
            return (1,)
    
    def get_transformation_history(self) -> List[Dict[str, Any]]:
        """Get history of all LLM transformations"""
        return self.transformation_history
    
    def clear_history(self):
        """Clear transformation history"""
        self.transformation_history = []
