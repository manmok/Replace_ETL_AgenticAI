import os
import pandas as pd
from etl_orchestrator import ETLOrchestrator

def create_sample_data():
    """Create sample data files for demonstration"""
    
    # Create sample CSV data
    sample_data = {
        'name': ['John Doe', '  Jane Smith  ', 'Bob Johnson', 'Alice Brown', 'John Doe'],
        'email': ['john@email.com', 'jane@email.com', 'bob@email.com', 'alice@email.com', 'john@email.com'],
        'age': ['25', '30', '35', '28', '25'],
        'city': ['New York', 'Los Angeles', 'Chicago', 'Houston', 'New York'],
        'salary': ['50000', '60000', '70000', '55000', '50000'],
        'join_date': ['2020-01-15', '2019-03-20', '2021-07-10', '2020-12-01', '2020-01-15']
    }
    
    df = pd.DataFrame(sample_data)
    df.to_csv('sample_data.csv', index=False)
    print("Created sample_data.csv")

def simple_csv_pipeline():
    """Simple CSV ETL pipeline example"""
    print("\n=== CSV ETL Pipeline Example ===")
    
    # Initialize orchestrator
    orchestrator = ETLOrchestrator()
    
    # Create pipeline configuration
    config = {
        "name": "csv_employee_pipeline",
        "description": "Process employee data from CSV",
        "input": {
            "files": ["sample_data.csv"],
            "batch": False,
            "params": {"encoding": "utf-8"}
        },
        "transformations": [
            {
                "type": "trim_whitespace",
                "params": {"columns": ["name", "city"]}
            },
            {
                "type": "remove_duplicates",
                "params": {"keep": "first"}
            },
            {
                "type": "convert_types",
                "params": {
                    "type_mapping": {
                        "age": "int",
                        "salary": "float",
                        "join_date": "datetime"
                    }
                }
            },
            {
                "type": "select_columns",
                "params": {
                    "columns": ["name", "email", "age", "city", "salary"]
                }
            }
        ],
        "output": {
            "path": "output/processed_employees.csv",
            "format": "csv",
            "params": {"index": False}
        }
    }
    
    # Run pipeline
    result = orchestrator.run_pipeline(config)
    
    if result['success']:
        print("Pipeline completed successfully!")
        print(f"Records processed: {result['pipeline_record']['records_processed']}")
        print(f"Execution time: {result['execution_time']:.2f} seconds")
        
        # Safely get output path
        output_path = result['output_results'].get('output_path', 'No output file generated')
        print(f"Output saved to: {output_path}")
        
        # Show sample of transformed data
        if hasattr(result['data'], 'head'):
            print("\nSample of transformed data:")
            print(result['data'].head())
    else:
        print(f"Pipeline failed: {result['error']}")

if __name__ == "__main__":
    print("Simple ETL Agent System Demo")
    print("=" * 50)
    
    # Create sample data
    create_sample_data()
    
    # Create output directory
    os.makedirs('output', exist_ok=True)
    
    # Run example
    simple_csv_pipeline()
    
    print("\nDemo completed! Check the 'output' directory for processed files.")
