# Developer - ETL Module

A comprehensive Python-based ETL (Extract, Transform, Load) system with specialized agents for file reading, data transformation, and AI-powered enhancements using Google Gemini. This module provides both programmatic APIs and a web interface for data processing tasks.

## Overview

The Developer - ETL Module consists of multiple components:

1. **FileReaderAgent** - Reads files from the local filesystem (CSV, JSON, Excel, TXT)
2. **DataTransformationAgent** - Applies various data cleaning and transformation operations
3. **LLMTransformationAgent** - Performs AI-powered transformations using Google Gemini
4. **ETLOrchestrator** - Coordinates the entire ETL pipeline
5. **Flask Web Interface** - Provides HTTP API and web UI for data transformation

## Features

### FileReaderAgent
- Support for multiple file formats: CSV, JSON, Excel, TXT
- Batch file processing
- File metadata extraction
- Error handling and logging

### DataTransformationAgent
- **Data Cleaning**: Trim whitespace, remove duplicates, fill missing values
- **Data Filtering**: Filter rows based on conditions
- **Column Operations**: Select, rename, convert data types
- **Text Processing**: Lower/upper case, remove special characters
- **Aggregation**: Group by and aggregate operations
- **Custom Transformations**: Apply custom functions
- **LLM Integration**: AI-powered data transformations

### LLMTransformationAgent
- **Google Gemini Integration**: Uses Gemini 2.5 Flash model
- **Prompt-based Transformations**: Custom prompts for data enhancement
- **Multiple Providers**: Support for OpenAI, Anthropic, and Google
- **Flexible Configuration**: User-provided API keys or environment variables

### Web Interface
- **Interactive Web UI**: Browser-based data transformation at http://localhost:5000
- **RESTful API**: HTTP endpoints for programmatic access
- **File Upload Support**: Direct file processing capabilities
- **Real-time Processing**: Live transformation results with feedback
- **API Key Management**: Secure user-provided authentication options

## Installation

Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Configuration

### Google API Key Setup

1. **Get API Key**: Visit https://aistudio.google.com/app/apikey
2. **Set API Key** (choose one method):

**Method 1: Configuration File (Recommended)**
```python
# config.py
GOOGLE_API_KEY = "your-api-key-here"
```

**Method 2: Environment Variable**
```bash
# Windows
set GOOGLE_API_KEY=your-api-key-here
# PowerShell
$env:GOOGLE_API_KEY="your-api-key-here"
```

**Method 3: Direct Usage**
```python
orchestrator = ETLOrchestrator(google_api_key="your-api-key-here")
```

## Quick Start

### Basic ETL (No API Key Required)
```python
from etl_orchestrator import ETLOrchestrator

# Initialize orchestrator
orchestrator = ETLOrchestrator()

# Create pipeline configuration
config = {
    "name": "basic_pipeline",
    "input": {"files": ["data.csv"], "batch": False},
    "transformations": [
        {"type": "trim_whitespace", "params": {}},
        {"type": "remove_duplicates", "params": {"keep": "first"}},
        {"type": "convert_types", "params": {"type_mapping": {"age": "int"}}}
    ],
    "output": {"path": "output/processed.csv", "format": "csv"}
}

# Run pipeline
result = orchestrator.run_pipeline(config)
```

### LLM-Powered Transformation
```python
from config import GOOGLE_API_KEY

# Initialize with API key
orchestrator = ETLOrchestrator(google_api_key=GOOGLE_API_KEY)

# LLM transformation configuration
config = {
    "name": "llm_pipeline",
    "input": {"files": ["data.csv"], "batch": False},
    "transformations": [
        {
            "type": "llm",
            "params": {
                "prompt": "Concatenate name and email in format: 'Name <email>'",
                "temperature": 0.2,
                "max_tokens": 1000
            }
        }
    ],
    "output": {"path": "output/enhanced.json", "format": "json"}
}

result = orchestrator.run_pipeline(config)
```

### Web Interface
```bash
# Start the Developer - ETL Module server
python flask_llm_app.py

# Access the web interface
# http://localhost:5000
```

The web interface provides:
- **CSV Data Input**: Paste CSV data directly into the web form
- **Automatic CSV Parsing**: Converts CSV to JSON for processing
- **Real-time Validation**: Checks CSV format and provides helpful error messages
- **File Upload Support**: Upload CSV files for processing
- **Interactive Prompts**: Custom LLM prompt configuration
- **API Key Management**: Secure authentication options

## Available Transformations

### Data Cleaning
- `trim_whitespace` - Remove leading/trailing whitespace
- `remove_duplicates` - Remove duplicate rows
- `fill_missing` - Fill missing values (mean, median, mode, forward, backward)

### Data Filtering
- `filter_rows` - Filter rows based on conditions
- `select_columns` - Select specific columns

### Column Operations
- `rename_columns` - Rename columns
- `convert_types` - Convert data types (int, float, datetime, string)

### Text Processing
- `normalize_text` - Normalize text (lowercase, uppercase, remove special chars)

### Aggregation
- `aggregate` - Group by and aggregate data

### LLM Transformations
- `llm` - Apply AI-powered transformations using custom prompts

## Configuration Examples

### Basic CSV Processing
```json
{
    "name": "csv_pipeline",
    "input": {"files": ["input.csv"], "batch": false},
    "transformations": [
        {"type": "trim_whitespace", "params": {}},
        {"type": "remove_duplicates", "params": {"keep": "first"}}
    ],
    "output": {"path": "output/processed.csv", "format": "csv"}
}
```

### LLM Enhancement
```json
{
    "name": "llm_enhancement",
    "input": {"files": ["employees.csv"], "batch": false},
    "transformations": [
        {
            "type": "llm",
            "params": {
                "prompt": "Create name_email_concat field in format: 'Name <email>'",
                "temperature": 0.1,
                "max_tokens": 1500
            }
        }
    ],
    "output": {"path": "output/enhanced.json", "format": "json"}
}
```

### Batch Processing
```json
{
    "name": "batch_pipeline",
    "input": {"files": ["file1.csv", "file2.json"], "batch": true},
    "transformations": [
        {"type": "trim_whitespace", "params": {}},
        {"type": "remove_duplicates", "params": {}}
    ],
    "output": {"path": "output/batch_result.json", "format": "json"}
}
```

## Running Examples

### Basic Examples (No API Key Required)
```bash
# Basic ETL without LLM
python simple_example.py

# Enhanced transformation demonstration
python demonstration_transformation.py

# Configuration-based examples
python config_example.py
```

### LLM Examples (Requires Google API Key)
```bash
# Gemini-powered transformations
python gemini_example.py

# User-provided API key examples
python user_api_example.py

# Enhanced LLM transformations
python simple_enhanced_transformation.py
```

### Web Interface
```bash
# Start Developer - ETL Module server
python flask_llm_app.py

# Test API endpoints
python flask_client_example.py
```

### Testing and Validation
```bash
# Test API key configuration
python simple_config_test.py

# Test basic functionality
python simple_csv_example.py
```

## File Structure

```
developer_etl_module/
├── Core Components
│   ├── file_reader_agent.py          # File reading functionality
│   ├── data_transformation_agent.py   # Data transformation functionality
│   ├── llm_transformation_agent.py    # LLM integration
│   └── etl_orchestrator.py            # Main ETL coordinator
├── Configuration
│   ├── config.py                      # System configuration with API keys
│   └── requirements.txt               # Python dependencies (organized by category)
├── Web Interface
│   ├── flask_llm_app.py               # Developer - ETL Module web application
│   └── flask_client_example.py        # API client examples
├── Examples and Demos
│   ├── simple_example.py              # Basic ETL example (no API key required)
│   ├── demonstration_transformation.py # Manual transformation demonstration
│   ├── example_usage.py               # Comprehensive usage examples
│   ├── gemini_example.py              # Google Gemini LLM examples
│   ├── user_api_example.py            # User API key management examples
│   ├── config_example.py              # Configuration-based examples
│   ├── enhanced_llm_transformation.py # Advanced LLM transformations
│   └── simple_enhanced_transformation.py # Simple LLM enhancements
├── Testing and Validation
│   ├── test_api_key.py                # API key testing utilities
│   ├── simple_config_test.py          # Configuration validation
│   └── simple_csv_example.py         # CSV processing test
└── Documentation
    └── README.md                      # This comprehensive documentation
```

## API Endpoints

### Web Interface Endpoints
- `GET /` - Web interface for data transformation
- `POST /transform` - Transform JSON data with LLM
- `POST /transform-file` - Transform uploaded files
- `GET /health` - System health check
- `GET /pipelines` - List available transformation types

### API Usage Example

#### Basic API Call
```python
import requests
import json

# Transform data via API
response = requests.post('http://localhost:5000/transform', json={
    "data": [
        {"name": "John", "email": "john@email.com", "age": 25},
        {"name": "Jane", "email": "jane@email.com", "age": 30}
    ],
    "prompt": "Create name_email_concat field in format: 'Name <email>'",
    "temperature": 0.2,
    "api_key": "your-google-api-key"  # Optional if configured in config.py
})

result = response.json()

if result['success']:
    print("Transformation successful!")
    print("Transformed data:")
    for item in result['data']:
        print(f"  {item}")
else:
    print(f"Error: {result['error']}")
```

#### File Upload API Call
```python
import requests

# Upload and transform file
with open('data.csv', 'rb') as f:
    files = {'file': f}
    data = {
        'prompt': 'Analyze this data and create summary fields',
        'temperature': 0.3,
        'api_key': 'your-google-api-key'
    }
    
    response = requests.post('http://localhost:5000/transform-file', 
                           files=files, data=data)
    
result = response.json()
print(result)
```

#### API Response Format
```json
{
  "success": true,
  "data": [
    {
      "name": "John",
      "email": "john@email.com",
      "age": 25,
      "name_email_concat": "John <john@email.com>"
    }
  ],
  "execution_time": 0.15,
  "transformations_applied": [
    {
      "type": "llm",
      "params": {
        "prompt": "Create name_email_concat field...",
        "temperature": 0.2
      }
    }
  ]
}
```

#### Error Response Format
```json
{
  "success": false,
  "error": "LLM transformation failed: API quota exceeded"
}
```

#### Advanced API Usage with Error Handling
```python
import requests
import json
import time

def transform_data_with_retry(data, prompt, max_retries=3):
    """Transform data with retry logic for API quota errors"""
    
    for attempt in range(max_retries):
        try:
            response = requests.post('http://localhost:5000/transform', json={
                "data": data,
                "prompt": prompt,
                "temperature": 0.2,
                "api_key": "your-google-api-key"
            })
            
            result = response.json()
            
            if result['success']:
                return result
            elif "quota" in result.get('error', '').lower():
                wait_time = 60  # Wait 1 minute for quota reset
                print(f"Quota exceeded, waiting {wait_time} seconds... (Attempt {attempt + 1}/{max_retries})")
                time.sleep(wait_time)
            else:
                return result
                
        except requests.exceptions.RequestException as e:
            print(f"Request failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(5)  # Wait 5 seconds before retry
            continue
    
    return {"success": False, "error": "Max retries exceeded"}

# Usage
result = transform_data_with_retry(
    data=[{"name": "John", "email": "john@email.com"}],
    prompt="Create name_email_concat field"
)

if result['success']:
    print("Success:", result['data'])
else:
    print("Failed:", result['error'])
```

## Error Handling

The system includes comprehensive error handling at multiple levels:

### 🔧 **File Reading Errors**
```python
# File not found
{
    "success": false,
    "error": "File not found: data.csv",
    "metadata": {}
}

# Invalid file format
{
    "success": false,
    "error": "Unsupported file format: .txt",
    "metadata": {}
}
```

### 🔄 **Transformation Errors**
```python
# Invalid transformation type
{
    "success": false,
    "error": "Unknown transformation type: invalid_type",
    "transformations_applied": [],
    "original_shape": (4, 6),
    "transformed_shape": (4, 6)
}

# LLM API errors
{
    "success": false,
    "error": "LLM transformation failed: API quota exceeded",
    "transformations_applied": [],
    "original_shape": (4, 6),
    "transformed_shape": (4, 6)
}
```

### 🌐 **API Error Responses**
```python
# Missing required fields
{
    "success": false,
    "error": "Data and prompt are required"
}

# Invalid JSON data
{
    "success": false,
    "error": "Invalid JSON format"
}

# Server errors
{
    "success": false,
    "error": "Internal server error: Connection timeout"
}
```

### 📊 **Pipeline Error Handling**
```python
# Partial success with warnings
{
    "success": true,
    "pipeline_record": {
        "start_time": "2024-01-02T17:30:00",
        "end_time": "2024-01-02T17:30:15",
        "execution_time_seconds": 0.15,
        "records_processed": 4,
        "failed_reads": 0,
        "transformations_count": 2
    },
    "read_results": [...],
    "transform_results": {...},
    "output_results": {...}
}
```

### 🛠️ **Common Error Scenarios & Solutions**

#### **File Reading Errors**
```python
# Error: File not found
try:
    result = orchestrator.run_pipeline(config)
except FileNotFoundError:
    print("Solution: Check file path and ensure file exists")
except PermissionError:
    print("Solution: Check file permissions")
```

#### **API Quota Errors**
```python
# Error: Quota exceeded
if "quota" in str(error).lower():
    print("Solution: Wait for quota reset or upgrade plan")
    print("Monitor usage at: https://ai.dev/usage")
```

#### **Transformation Errors**
```python
# Error: Invalid transformation
if "Unknown transformation" in str(error):
    print("Solution: Check transformation type spelling")
    print("Available types: trim_whitespace, remove_duplicates, llm, etc.")
```

#### **Connection Errors**
```python
# Error: Connection refused
if "Connection refused" in str(error):
    print("Solution: Ensure Flask server is running")
    print("Run: python flask_llm_app.py")
```

### 📝 **Logging and Debugging**

#### **Enable Debug Logging**
```python
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Pipeline with logging
orchestrator = ETLOrchestrator()
result = orchestrator.run_pipeline(config)

if not result['success']:
    logger.error(f"Pipeline failed: {result['error']}")
    logger.debug(f"Pipeline record: {result.get('pipeline_record', {})}")
```

#### **Pipeline History**
```python
# Check execution history
history = orchestrator.get_pipeline_history()
for pipeline in history:
    print(f"Pipeline: {pipeline['name']}")
    print(f"Status: {'Success' if pipeline['success'] else 'Failed'}")
    print(f"Records: {pipeline['records_processed']}")
```

### 🔍 **Error Recovery Strategies**

#### **Automatic Retry Logic**
```python
import time
from requests.exceptions import RequestException

def robust_api_call(url, payload, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = requests.post(url, json=payload, timeout=30)
            return response.json()
        except RequestException as e:
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff
                print(f"Attempt {attempt + 1} failed, retrying in {wait_time}s...")
                time.sleep(wait_time)
            else:
                return {"success": False, "error": f"Max retries exceeded: {str(e)}"}
```

#### **Graceful Degradation**
```python
def transform_with_fallback(data, prompt):
    try:
        # Try LLM transformation first
        result = llm_transform(data, prompt)
        if result['success']:
            return result
    except Exception as e:
        print(f"LLM failed: {e}, using fallback")
    
    # Fallback to basic transformation
    return basic_transform(data)
```

### 📈 **Monitoring and Alerting**

#### **Health Check Implementation**
```python
def system_health_check():
    health = requests.get('http://localhost:5000/health').json()
    
    if not health['api_key_configured']:
        print("WARNING: No API key configured")
    
    if health['status'] != 'healthy':
        print("ERROR: System unhealthy")
        return False
    
    print("System healthy")
    return True
```

#### **Performance Monitoring**
```python
import time

def monitor_pipeline_performance(config):
    start_time = time.time()
    result = orchestrator.run_pipeline(config)
    end_time = time.time()
    
    performance = {
        'execution_time': end_time - start_time,
        'records_per_second': len(result.get('data', [])) / (end_time - start_time),
        'memory_usage': result.get('memory_stats', {}),
        'error_rate': result.get('error_count', 0) / result.get('total_operations', 1)
    }
    
    return performance
```

### 🎯 **Best Practices for Error Handling**

1. **Always check success status** before accessing result data
2. **Implement retry logic** for network operations
3. **Use try-catch blocks** for file operations
4. **Log errors** with context for debugging
5. **Provide fallback options** for critical operations
6. **Monitor system health** regularly
7. **Set appropriate timeouts** for API calls
8. **Validate input data** before processing

This comprehensive error handling ensures the Developer - ETL Module operates reliably even under adverse conditions.

## Performance Considerations

- Use batch processing for multiple files
- Consider memory usage for large datasets
- Use appropriate data types to optimize memory
- Monitor pipeline execution time
- Handle API rate limits and quotas

## API Quota Management

### Google Gemini Quotas
- Free tier has limited requests per minute/day
- Monitor usage at: https://ai.dev/usage
- Upgrade plan for higher limits at: https://ai.google.dev/
- System handles quota errors gracefully

### Best Practices
- Implement retry logic for quota errors
- Use efficient prompts to minimize token usage
- Cache results when possible
- Monitor API usage and costs

## Security

- API keys are never logged or exposed
- Support for user-provided API keys
- Environment variable fallbacks
- Secure file upload handling
- Input validation and sanitization

## Extending the System

### Adding New Transformations
```python
def _custom_transform(self, data, **params):
    # Your custom logic here
    return processed_data
```

### Adding New File Formats
```python
def _read_custom_format(self, file_path, **params):
    # Your custom file reading logic
    return data
```

### Custom LLM Providers
```python
def _call_custom_llm(self, prompt, **kwargs):
    # Your custom LLM integration
    return response
```

## Support and Documentation

For issues and questions:
1. **Check Examples**: Review the examples directory for usage patterns
2. **API Documentation**: Use the health endpoint (`/health`) to check system status
3. **Configuration**: Test API key setup with `python simple_config_test.py`
4. **Web Interface**: Access http://localhost:5000 for interactive testing
5. **Error Logs**: Monitor Flask server output for detailed error information

### Quick Start Checklist
- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Configure Google API key in `config.py` or environment variable
- [ ] Test basic functionality: `python simple_example.py`
- [ ] Start web interface: `python flask_llm_app.py`
- [ ] Access web interface: http://localhost:5000
- [ ] Test API key: `python simple_config_test.py`


