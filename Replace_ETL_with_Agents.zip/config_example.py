from config import GOOGLE_API_KEY, LLM_PROVIDER, LLM_MODEL
from etl_orchestrator import ETLOrchestrator
import pandas as pd
import os

def example_with_config():
    """Example using configuration file with API key"""
    
    print("🔑 Using API Key from Config File")
    print(f"Provider: {LLM_PROVIDER}")
    print(f"Model: {LLM_MODEL}")
    print(f"API Key: {'✅ Configured' if GOOGLE_API_KEY else '❌ Not set'}")
    
    # Create sample data
    sample_data = {
        'product': ['Gaming Laptop', 'Wireless Mouse', 'Mechanical Keyboard'],
        'description': [
            'High-performance laptop with RTX 4090 and 32GB RAM',
            'Ergonomic wireless mouse with precision sensor',
            'RGB mechanical keyboard with Cherry MX switches'
        ],
        'price': [2499.99, 79.99, 149.99]
    }
    
    df = pd.DataFrame(sample_data)
    df.to_csv('products.csv', index=False)
    print("✅ Created products.csv")
    
    # Initialize orchestrator with config
    orchestrator = ETLOrchestrator(
        google_api_key=GOOGLE_API_KEY,
        llm_provider=LLM_PROVIDER,
        llm_model=LLM_MODEL
    )
    
    # LLM transformation configuration
    config = {
        "name": "product_analysis",
        "description": "Analyze products using Gemini",
        "input": {
            "files": ["products.csv"],
            "batch": False
        },
        "transformations": [
            {
                "type": "llm",
                "params": {
                    "prompt": """
                    For each product, extract:
                    1. product_category (e.g., "computer", "peripheral", "accessory")
                    2. target_audience (e.g., "gamers", "professionals", "general")
                    3. performance_tier (e.g., "high_end", "mid_range", "budget")
                    4. key_features (list of main features)
                    
                    Return as JSON array with analysis.
                    """,
                    "temperature": 0.2,
                    "max_tokens": 1500
                }
            }
        ],
        "output": {
            "path": "output/product_analysis.json",
            "format": "json"
        }
    }
    
    # Run pipeline
    print("\n🚀 Running Product Analysis Pipeline...")
    result = orchestrator.run_pipeline(config)
    
    if result['success']:
        print("✅ Pipeline completed successfully!")
        print(f"📊 Records processed: {result['pipeline_record']['records_processed']}")
        print(f"⏱️  Execution time: {result['execution_time']:.2f} seconds")
        
        output_path = result['output_results'].get('output_path', 'No output file generated')
        print(f"📁 Output saved to: {output_path}")
        
        # Show results
        if os.path.exists(output_path):
            import json
            with open(output_path, 'r') as f:
                analysis_data = json.load(f)
            
            print("\n📋 Product Analysis Results:")
            for i, item in enumerate(analysis_data):
                print(f"\nProduct {i+1}:")
                print(f"  Category: {item.get('product_category', 'N/A')}")
                print(f"  Audience: {item.get('target_audience', 'N/A')}")
                print(f"  Tier: {item.get('performance_tier', 'N/A')}")
                print(f"  Features: {item.get('key_features', 'N/A')}")
        
    else:
        print(f"❌ Pipeline failed: {result['error']}")

def quick_llm_test():
    """Quick test of LLM with config"""
    
    print("\n🧪 Quick LLM Test")
    print("-" * 20)
    
    # Simple test data
    test_data = [
        {"text": "This product is amazing!", "id": 1},
        {"text": "Terrible experience, would not recommend.", "id": 2},
        {"text": "It's okay, does what it says.", "id": 3}
    ]
    
    # Create orchestrator with config
    orchestrator = ETLOrchestrator(google_api_key=GOOGLE_API_KEY)
    
    # Simple transformation
    transformations = [{
        'type': 'llm',
        'params': {
            'prompt': 'Analyze sentiment (positive/negative/neutral) for each text. Return as JSON array.',
            'temperature': 0.1,
            'max_tokens': 200
        }
    }]
    
    try:
        result = orchestrator.transformer.transform(test_data, transformations)
        
        if result['success']:
            print("✅ LLM test successful!")
            print("Results:")
            for item in result['data']:
                print(f"  {item}")
        else:
            print(f"❌ LLM test failed: {result['error']}")
            
    except Exception as e:
        print(f"❌ Error: {str(e)}")

if __name__ == "__main__":
    print("ETL System with Configuration File")
    print("=" * 40)
    
    # Create output directory
    os.makedirs('output', exist_ok=True)
    
    # Run examples
    try:
        quick_llm_test()
        example_with_config()
        print("\n✨ Configuration-based examples completed!")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print("Make sure your Google API key is valid and has Gemini API access.")
