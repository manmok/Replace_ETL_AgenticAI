import os
import pandas as pd
import json
import csv
from typing import Dict, Any, List, Optional
from pathlib import Path
import logging

class FileReaderAgent:
    """
    Agent responsible for reading files from the local filesystem.
    Supports multiple file formats: CSV, JSON, TXT, Excel
    """
    
    def __init__(self, base_directory: str = None):
        self.base_directory = base_directory or os.getcwd()
        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        
    def read_file(self, file_path: str, **kwargs) -> Dict[str, Any]:
        """
        Read a file and return its contents with metadata.
        
        Args:
            file_path: Path to the file to read
            **kwargs: Additional parameters for specific file types
            
        Returns:
            Dictionary containing file data and metadata
        """
        try:
            full_path = os.path.join(self.base_directory, file_path) if self.base_directory else file_path
            full_path = os.path.abspath(full_path)
            
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"File not found: {full_path}")
                
            file_info = self._get_file_info(full_path)
            file_ext = file_info['extension'].lower()
            
            data = None
            
            if file_ext == '.csv':
                data = self._read_csv(full_path, **kwargs)
            elif file_ext == '.json':
                data = self._read_json(full_path, **kwargs)
            elif file_ext in ['.xlsx', '.xls']:
                data = self._read_excel(full_path, **kwargs)
            elif file_ext == '.txt':
                data = self._read_text(full_path, **kwargs)
            else:
                raise ValueError(f"Unsupported file format: {file_ext}")
                
            return {
                'data': data,
                'metadata': file_info,
                'success': True,
                'error': None
            }
            
        except Exception as e:
            self.logger.error(f"Error reading file {file_path}: {str(e)}")
            return {
                'data': None,
                'metadata': {},
                'success': False,
                'error': str(e)
            }
    
    def _read_csv(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Read CSV file"""
        default_params = {'encoding': 'utf-8'}
        default_params.update(kwargs)
        return pd.read_csv(file_path, **default_params)
    
    def _read_json(self, file_path: str, **kwargs) -> Dict[str, Any]:
        """Read JSON file"""
        with open(file_path, 'r', encoding='utf-8') as f:
            if kwargs.get('lines', False):
                return [json.loads(line) for line in f]
            return json.load(f)
    
    def _read_excel(self, file_path: str, **kwargs) -> Dict[str, pd.DataFrame]:
        """Read Excel file"""
        default_params = {'sheet_name': None}
        default_params.update(kwargs)
        return pd.read_excel(file_path, **default_params)
    
    def _read_text(self, file_path: str, **kwargs) -> str:
        """Read text file"""
        encoding = kwargs.get('encoding', 'utf-8')
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    
    def _get_file_info(self, file_path: str) -> Dict[str, Any]:
        """Get file metadata"""
        stat = os.stat(file_path)
        path_obj = Path(file_path)
        
        return {
            'name': path_obj.name,
            'extension': path_obj.suffix,
            'size_bytes': stat.st_size,
            'created': stat.st_ctime,
            'modified': stat.st_mtime,
            'absolute_path': os.path.abspath(file_path)
        }
    
    def list_files(self, directory: str = None, pattern: str = "*") -> List[str]:
        """
        List files in a directory matching a pattern.
        
        Args:
            directory: Directory to search (defaults to base_directory)
            pattern: File pattern to match (defaults to "*")
            
        Returns:
            List of file paths
        """
        search_dir = directory or self.base_directory
        path_obj = Path(search_dir)
        
        if not path_obj.exists():
            raise FileNotFoundError(f"Directory not found: {search_dir}")
            
        return [str(f) for f in path_obj.glob(pattern) if f.is_file()]
    
    def batch_read(self, file_paths: List[str], **kwargs) -> List[Dict[str, Any]]:
        """
        Read multiple files in batch.
        
        Args:
            file_paths: List of file paths to read
            **kwargs: Additional parameters for reading
            
        Returns:
            List of results for each file
        """
        results = []
        for file_path in file_paths:
            result = self.read_file(file_path, **kwargs)
            results.append(result)
        return results
