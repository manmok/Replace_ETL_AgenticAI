import pandas as pd
import json
import re
from typing import Dict, Any, List, Optional, Union, Callable
import logging
from datetime import datetime
import numpy as np
from llm_transformation_agent import LLMTransformationAgent

class DataTransformationAgent:
    """
    Agent responsible for trimming and transforming data.
    Supports various data cleaning and transformation operations.
    """
    
    def __init__(self, llm_api_key: str = None, llm_provider: str = "google", llm_model: str = "gemini-2.0-flash-exp"):
        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        self.transformation_history = []
        self.llm_agent = LLMTransformationAgent(
            api_key=llm_api_key,
            provider=llm_provider,
            model=llm_model
        )
    
    def transform(self, data: Any, transformations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Apply a series of transformations to data.
        
        Args:
            data: Input data (DataFrame, dict, list, or string)
            transformations: List of transformation configurations
            
        Returns:
            Dictionary containing transformed data and metadata
        """
        try:
            result = data
            applied_transformations = []
            
            for transform in transformations:
                transform_type = transform.get('type')
                params = transform.get('params', {})
                
                if transform_type == 'trim_whitespace':
                    result = self._trim_whitespace(result, **params)
                elif transform_type == 'remove_duplicates':
                    result = self._remove_duplicates(result, **params)
                elif transform_type == 'filter_rows':
                    result = self._filter_rows(result, **params)
                elif transform_type == 'select_columns':
                    result = self._select_columns(result, **params)
                elif transform_type == 'rename_columns':
                    result = self._rename_columns(result, **params)
                elif transform_type == 'convert_types':
                    result = self._convert_types(result, **params)
                elif transform_type == 'fill_missing':
                    result = self._fill_missing(result, **params)
                elif transform_type == 'normalize_text':
                    result = self._normalize_text(result, **params)
                elif transform_type == 'aggregate':
                    result = self._aggregate(result, **params)
                elif transform_type == 'custom':
                    result = self._apply_custom_transform(result, **params)
                elif transform_type == 'llm':
                    result = self._apply_llm_transform(result, **params)
                else:
                    raise ValueError(f"Unknown transformation type: {transform_type}")
                
                applied_transformations.append({
                    'type': transform_type,
                    'params': params,
                    'timestamp': datetime.now().isoformat()
                })
            
            self.transformation_history.extend(applied_transformations)
            
            return {
                'data': result,
                'transformations_applied': applied_transformations,
                'success': True,
                'error': None,
                'original_shape': self._get_shape(data),
                'transformed_shape': self._get_shape(result)
            }
            
        except Exception as e:
            self.logger.error(f"Error during transformation: {str(e)}")
            return {
                'data': data,
                'transformations_applied': [],
                'success': False,
                'error': str(e),
                'original_shape': self._get_shape(data),
                'transformed_shape': self._get_shape(data)
            }
    
    def _trim_whitespace(self, data: Any, columns: List[str] = None) -> Any:
        """Trim whitespace from string columns"""
        if isinstance(data, pd.DataFrame):
            if columns is None:
                columns = data.select_dtypes(include=['object']).columns.tolist()
            for col in columns:
                if col in data.columns:
                    data[col] = data[col].astype(str).str.strip()
        elif isinstance(data, str):
            data = data.strip()
        elif isinstance(data, list):
            # Handle list of dictionaries (normalized format)
            for item in data:
                if isinstance(item, dict):
                    if columns is None:
                        # Trim all string values in the dict
                        for key, value in item.items():
                            if isinstance(value, str):
                                item[key] = value.strip()
                    else:
                        # Trim only specified columns
                        for col in columns:
                            if col in item and isinstance(item[col], str):
                                item[col] = item[col].strip()
                elif isinstance(item, str):
                    # Handle list of strings
                    item = item.strip()
        return data
    
    def _remove_duplicates(self, data: Any, subset: List[str] = None, keep: str = 'first') -> Any:
        """Remove duplicate rows"""
        if isinstance(data, pd.DataFrame):
            return data.drop_duplicates(subset=subset, keep=keep)
        elif isinstance(data, list):
            seen = []
            result = []
            for item in data:
                # Handle different data types in the list
                if isinstance(item, pd.DataFrame):
                    # For DataFrames, check if an equivalent DataFrame already exists
                    is_duplicate = False
                    for seen_item in seen:
                        if isinstance(seen_item, pd.DataFrame):
                            if item.equals(seen_item):
                                is_duplicate = True
                                break
                    if not is_duplicate:
                        seen.append(item)
                        result.append(item)
                elif isinstance(item, dict):
                    # For dictionaries, use tuple conversion for comparison
                    item_tuple = tuple(sorted(item.items()))
                    if item_tuple not in seen:
                        seen.append(item_tuple)
                        result.append(item)
                else:
                    # For other types, use direct comparison
                    if item not in seen:
                        seen.append(item)
                        result.append(item)
            return result
        return data
    
    def _filter_rows(self, data: Any, condition: str = None, **kwargs) -> Any:
        """Filter rows based on conditions"""
        if isinstance(data, pd.DataFrame):
            if condition:
                return data.query(condition)
            elif 'column' in kwargs and 'value' in kwargs:
                return data[data[kwargs['column']] == kwargs['value']]
        return data
    
    def _select_columns(self, data: Any, columns: List[str]) -> Any:
        """Select specific columns"""
        if isinstance(data, pd.DataFrame):
            return data[columns]
        elif isinstance(data, list) and data and isinstance(data[0], dict):
            return [{k: v for k, v in item.items() if k in columns} for item in data]
        return data
    
    def _rename_columns(self, data: Any, mapping: Dict[str, str]) -> Any:
        """Rename columns"""
        if isinstance(data, pd.DataFrame):
            return data.rename(columns=mapping)
        elif isinstance(data, list) and data and isinstance(data[0], dict):
            return [{mapping.get(k, k): v for k, v in item.items()} for item in data]
        return data
    
    def _convert_types(self, data: Any, type_mapping: Dict[str, str]) -> Any:
        """Convert data types"""
        if isinstance(data, pd.DataFrame):
            for col, dtype in type_mapping.items():
                if col in data.columns:
                    if dtype == 'datetime':
                        data[col] = pd.to_datetime(data[col])
                    else:
                        data[col] = data[col].astype(dtype)
            return data
        return data
    
    def _fill_missing(self, data: Any, strategy: str = 'mean', value: Any = None) -> Any:
        """Fill missing values"""
        if isinstance(data, pd.DataFrame):
            if value is not None:
                return data.fillna(value)
            elif strategy == 'mean':
                return data.fillna(data.mean())
            elif strategy == 'median':
                return data.fillna(data.median())
            elif strategy == 'mode':
                return data.fillna(data.mode().iloc[0])
            elif strategy == 'forward':
                return data.fillna(method='ffill')
            elif strategy == 'backward':
                return data.fillna(method='bfill')
        return data
    
    def _normalize_text(self, data: Any, columns: List[str] = None, operations: List[str] = None) -> Any:
        """Normalize text data"""
        if operations is None:
            operations = ['lower', 'remove_special_chars']
            
        if isinstance(data, pd.DataFrame):
            if columns is None:
                columns = data.select_dtypes(include=['object']).columns.tolist()
            
            for col in columns:
                if col in data.columns:
                    for op in operations:
                        if op == 'lower':
                            data[col] = data[col].str.lower()
                        elif op == 'upper':
                            data[col] = data[col].str.upper()
                        elif op == 'remove_special_chars':
                            data[col] = data[col].str.replace(r'[^a-zA-Z0-9\s]', '', regex=True)
                        elif op == 'remove_extra_spaces':
                            data[col] = data[col].str.replace(r'\s+', ' ', regex=True).str.strip()
        return data
    
    def _aggregate(self, data: Any, group_by: List[str], aggregations: Dict[str, str]) -> Any:
        """Aggregate data"""
        if isinstance(data, pd.DataFrame):
            return data.groupby(group_by).agg(aggregations).reset_index()
        return data
    
    def _apply_custom_transform(self, data: Any, function: Callable = None, **kwargs) -> Any:
        """Apply custom transformation function"""
        if function and callable(function):
            return function(data, **kwargs)
        return data
    
    def _apply_llm_transform(self, data: Any, prompt: str, **kwargs) -> Any:
        """Apply LLM-based transformation"""
        llm_result = self.llm_agent.transform_with_llm(data, prompt, **kwargs)
        if llm_result['success']:
            return llm_result['data']
        else:
            raise Exception(f"LLM transformation failed: {llm_result['error']}")
    
    def _get_shape(self, data: Any) -> tuple:
        """Get shape of data"""
        if isinstance(data, pd.DataFrame):
            return data.shape
        elif isinstance(data, (list, tuple)):
            return (len(data),)
        elif isinstance(data, dict):
            return (len(data),)
        else:
            return (1,)
    
    def get_transformation_summary(self) -> Dict[str, Any]:
        """Get summary of all transformations applied"""
        return {
            'total_transformations': len(self.transformation_history),
            'transformations': self.transformation_history,
            'last_updated': datetime.now().isoformat()
        }
    
    def clear_history(self):
        """Clear transformation history"""
        self.transformation_history = []
