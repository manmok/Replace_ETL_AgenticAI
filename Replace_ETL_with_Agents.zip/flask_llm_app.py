from flask import Flask, request, jsonify, render_template_string
import os
import pandas as pd
import json
from etl_orchestrator import ETLOrchestrator
from data_transformation_agent import DataTransformationAgent
from config import GOOGLE_API_KEY as CONFIG_API_KEY
import tempfile
import uuid

app = Flask(__name__)

# Initialize ETL system with LLM support (will be configured per request)
orchestrator = ETLOrchestrator()

# HTML template for the web interface
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Developer - ETL Module</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .container { max-width: 800px; margin: 0 auto; }
        .form-group { margin: 20px 0; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        textarea, input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
        textarea { height: 100px; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .result { margin: 20px 0; padding: 20px; background: #f8f9fa; border-radius: 4px; }
        .error { background: #f8d7da; color: #721c24; }
        .success { background: #d4edda; color: #155724; }
        pre { background: #f1f1f1; padding: 10px; border-radius: 4px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Developer - ETL Module</h1>
        <p>Transform your data using AI-powered transformations</p>
        
        <form id="transformForm">
            <div class="form-group">
                <label for="dataInput">Input Data (CSV format):</label>
                <textarea id="dataInput" placeholder='name,email,age,city
John Doe,john@email.com,25,New York
Jane Smith,jane@email.com,30,Los Angeles'></textarea>
            </div>
            
            <div class="form-group">
                <label for="apiKey">Google API Key:</label>
                <input type="password" id="apiKey" placeholder="Enter your Google API key (optional)">
            </div>
            
            <div class="form-group">
                <label for="prompt">LLM Prompt:</label>
                <textarea id="prompt" placeholder="Transform this data by..."></textarea>
            </div>
            
            <div class="form-group">
                <label for="temperature">Temperature (0-1):</label>
                <input type="number" id="temperature" value="0.3" min="0" max="1" step="0.1">
            </div>
            
            <button type="submit">Transform Data</button>
        </form>
        
        <div id="result" class="result" style="display: none;"></div>
    </div>

    <script>
        document.getElementById('transformForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const dataInput = document.getElementById('dataInput').value;
            const apiKey = document.getElementById('apiKey').value;
            const prompt = document.getElementById('prompt').value;
            const temperature = parseFloat(document.getElementById('temperature').value);
            const resultDiv = document.getElementById('result');
            
            if (!dataInput || !prompt) {
                alert('Please provide both data and prompt');
                return;
            }
            
            try {
                // Parse CSV data
                const csvData = dataInput.trim();
                if (!csvData) {
                    alert('Please provide CSV data');
                    return;
                }
                
                // Convert CSV to array of objects
                const lines = csvData.split('\n').filter(line => line.trim());
                const headers = lines[0].split(',').map(h => h.trim());
                
                const data = lines.slice(1).map(line => {
                    const values = line.split(',').map(v => v.trim());
                    const obj = {};
                    headers.forEach((header, index) => {
                        obj[header] = values[index] || '';
                    });
                    return obj;
                });
                
                resultDiv.style.display = 'block';
                resultDiv.className = 'result';
                resultDiv.innerHTML = '<p>Processing with AI...</p>';
                
                const response = await fetch('/transform', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        data: data,
                        prompt: prompt,
                        temperature: temperature,
                        api_key: apiKey
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    resultDiv.className = 'result success';
                    resultDiv.innerHTML = `
                        <h3>✅ Transformation Successful!</h3>
                        <p><strong>Execution Time:</strong> ${result.execution_time}s</p>
                        <h4>Transformed Data:</h4>
                        <pre>${JSON.stringify(result.data, null, 2)}</pre>
                    `;
                } else {
                    resultDiv.className = 'result error';
                    resultDiv.innerHTML = `
                        <h3>❌ Transformation Failed</h3>
                        <p><strong>Error:</strong> ${result.error}</p>
                    `;
                }
                
            } catch (error) {
                if (error instanceof SyntaxError) {
                    resultDiv.className = 'result error';
                    resultDiv.innerHTML = `
                        <h3>CSV Format Error</h3>
                        <p><strong>Error:</strong> Invalid CSV format</p>
                        <p>Please ensure your CSV data has proper headers and consistent columns.</p>
                        <p>Example format:<br>
                        name,email,age,city<br>
                        John,john@email.com,25,New York</p>
                        </p>
                    `;
                } else {
                    resultDiv.className = 'result error';
                    resultDiv.innerHTML = `
                        <h3>Error</h3>
                        <p>${error.message}</p>
                    `;
                }
            }
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    """Web interface for LLM ETL"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/transform', methods=['POST'])
def transform_data():
    """API endpoint for LLM data transformation"""
    try:
        data = request.json.get('data')
        prompt = request.json.get('prompt')
        temperature = request.json.get('temperature', 0.3)
        api_key = request.json.get('api_key')
        
        if not data or not prompt:
            return jsonify({
                'success': False,
                'error': 'Data and prompt are required'
            }), 400
        
        # Create new orchestrator with user-provided API key or config fallback
        current_orchestrator = ETLOrchestrator(
            google_api_key=api_key or CONFIG_API_KEY or os.getenv("GOOGLE_API_KEY")
        )
        
        # Create LLM transformation configuration
        transformations = [{
            'type': 'llm',
            'params': {
                'prompt': prompt,
                'temperature': temperature,
                'max_tokens': 2000
            }
        }]
        
        # Apply transformation
        result = current_orchestrator.transformer.transform(data, transformations)
        
        if result['success']:
            return jsonify({
                'success': True,
                'data': result['data'],
                'execution_time': 0.1,  # Placeholder for actual timing
                'transformations_applied': result['transformations_applied']
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/transform-file', methods=['POST'])
def transform_file():
    """API endpoint for file-based LLM transformation"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'}), 400
        
        file = request.files['file']
        prompt = request.form.get('prompt')
        temperature = float(request.form.get('temperature', 0.3))
        api_key = request.form.get('api_key')
        
        if not prompt:
            return jsonify({'success': False, 'error': 'Prompt is required'}), 400
        
        # Create orchestrator with user-provided API key or config fallback
        current_orchestrator = ETLOrchestrator(
            google_api_key=api_key or CONFIG_API_KEY or os.getenv("GOOGLE_API_KEY")
        )
        
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp_file:
            file.save(tmp_file.name)
            tmp_file_path = tmp_file.name
        
        try:
            # Read file data
            read_result = current_orchestrator.file_reader.read_file(tmp_file_path)
            
            if not read_result['success']:
                return jsonify({'success': False, 'error': read_result['error']}), 400
            
            # Apply LLM transformation
            transformations = [{
                'type': 'llm',
                'params': {
                    'prompt': prompt,
                    'temperature': temperature,
                    'max_tokens': 2000
                }
            }]
            
            result = current_orchestrator.transformer.transform(read_result['data'], transformations)
            
            if result['success']:
                return jsonify({
                    'success': True,
                    'data': result['data'],
                    'original_shape': result['original_shape'],
                    'transformed_shape': result['transformed_shape']
                })
            else:
                return jsonify({'success': False, 'error': result['error']}), 500
                
        finally:
            # Clean up temporary file
            os.unlink(tmp_file_path)
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'llm_provider': 'google',
        'llm_model': 'gemini-2.0-flash-exp',
        'api_key_sources': {
            'config_file': bool(CONFIG_API_KEY),
            'environment': bool(os.getenv("GOOGLE_API_KEY")),
            'user_input_supported': True
        },
        'api_key_configured': bool(CONFIG_API_KEY or os.getenv("GOOGLE_API_KEY"))
    })

@app.route('/pipelines', methods=['GET'])
def list_pipelines():
    """List available transformation pipelines"""
    pipelines = {
        'text_analysis': {
            'description': 'Analyze text for sentiment, entities, and key topics',
            'example_prompt': 'Analyze this text for sentiment, extract key entities, and identify main topics.'
        },
        'data_enrichment': {
            'description': 'Enrich data with additional information',
            'example_prompt': 'Add relevant categories, tags, and metadata to this data.'
        },
        'format_conversion': {
            'description': 'Convert data between different formats',
            'example_prompt': 'Convert this data to a standardized format with consistent field names.'
        },
        'quality_check': {
            'description': 'Check data quality and suggest improvements',
            'example_prompt': 'Check this data for quality issues and suggest improvements.'
        }
    }
    
    return jsonify({
        'pipelines': pipelines,
        'total_pipelines': len(pipelines)
    })

if __name__ == "__main__":
    print("Starting Developer - ETL Module Server...")
    print("Web Interface: http://localhost:5000")
    print("API Endpoint: http://localhost:5000/transform")
    print("Health Check: http://localhost:5000/health")
    
    # Check for API key
    if not os.getenv("GOOGLE_API_KEY") and not CONFIG_API_KEY:
        print("WARNING: No Google API key configured!")
        print("Set GOOGLE_API_KEY environment variable or add to config.py")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
