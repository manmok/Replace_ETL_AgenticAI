# Configuration file for ETL system
GOOGLE_API_KEY = "AIzaSyBaTYo84ZeR41hsI6vDxBKvjfgTFFMvZ_g"

# LLM Configuration
LLM_PROVIDER = "google"
LLM_MODEL = "gemini-2.0-flash-exp"
DEFAULT_TEMPERATURE = 0.3
DEFAULT_MAX_TOKENS = 2000

# File Processing Configuration
DEFAULT_ENCODING = "utf-8"
OUTPUT_DIRECTORY = "output"
SUPPORTED_FORMATS = ["csv", "json", "xlsx", "txt"]
