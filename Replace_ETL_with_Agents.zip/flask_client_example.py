import requests
import json

def test_flask_api():
    """Test the Flask LLM ETL API"""
    
    base_url = "http://localhost:5000"
    
    print("🌐 Testing Flask LLM ETL API")
    print("=" * 40)
    
    # Test health check
    print("\n🏥 Health Check:")
    try:
        response = requests.get(f"{base_url}/health")
        if response.status_code == 200:
            health_data = response.json()
            print(f"✅ Status: {health_data['status']}")
            print(f"🤖 LLM Provider: {health_data['llm_provider']}")
            print(f"🧠 Model: {health_data['llm_model']}")
            print(f"🔑 API Key Configured: {health_data['api_key_configured']}")
        else:
            print(f"❌ Health check failed: {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Flask server. Make sure it's running on http://localhost:5000")
        return
    
    # Test data transformation
    print("\n🔄 Testing Data Transformation:")
    
    sample_data = [
        {"name": "John Doe", "age": 25, "city": "New York"},
        {"name": "Jane Smith", "age": 30, "city": "Los Angeles"},
        {"name": "Bob Johnson", "age": 35, "city": "Chicago"}
    ]
    
    transformation_prompt = """
    Analyze this data and:
    1. Add a 'generation' category based on age (Gen Z: <25, Millennial: 25-40, Gen X: 40-55)
    2. Add a 'region' based on city (West: Los Angeles, East: New York, Midwest: Chicago)
    3. Add a 'life_stage' based on age and generation
    Return the enhanced data as JSON.
    """
    
    payload = {
        "data": sample_data,
        "prompt": transformation_prompt,
        "temperature": 0.3
    }
    
    try:
        response = requests.post(f"{base_url}/transform", json=payload)
        if response.status_code == 200:
            result = response.json()
            if result['success']:
                print("✅ Transformation successful!")
                print(f"⏱️  Execution Time: {result['execution_time']}s")
                print("\n📊 Original Data:")
                print(json.dumps(sample_data, indent=2))
                print("\n🤖 Transformed Data:")
                print(json.dumps(result['data'], indent=2))
            else:
                print(f"❌ Transformation failed: {result['error']}")
        else:
            print(f"❌ API error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Request failed: {str(e)}")
    
    # Test available pipelines
    print("\n📋 Available Pipelines:")
    try:
        response = requests.get(f"{base_url}/pipelines")
        if response.status_code == 200:
            pipelines_data = response.json()
            print(f"✅ Found {pipelines_data['total_pipelines']} pipelines:")
            for name, info in pipelines_data['pipelines'].items():
                print(f"  📌 {name}: {info['description']}")
                print(f"     Example: {info['example_prompt'][:80]}...")
        else:
            print(f"❌ Failed to get pipelines: {response.status_code}")
    except Exception as e:
        print(f"❌ Request failed: {str(e)}")

def test_text_analysis_example():
    """Example: Text analysis using Flask API"""
    
    base_url = "http://localhost:5000"
    
    print("\n\n📝 Text Analysis Example:")
    print("-" * 30)
    
    text_data = [
        {"text": "I love this product! It's amazing and works perfectly.", "id": 1},
        {"text": "Terrible experience, the product broke after one day.", "id": 2},
        {"text": "It's okay, does what it's supposed to do but nothing special.", "id": 3}
    ]
    
    sentiment_prompt = """
    Analyze each text and determine:
    1. Sentiment (positive, negative, neutral)
    2. Confidence score (0-1)
    3. Key emotions detected
    4. Main topic category
    
    Return results as JSON array with original text plus analysis.
    """
    
    payload = {
        "data": text_data,
        "prompt": sentiment_prompt,
        "temperature": 0.2
    }
    
    try:
        response = requests.post(f"{base_url}/transform", json=payload)
        if response.status_code == 200:
            result = response.json()
            if result['success']:
                print("✅ Text analysis completed!")
                print("\n📊 Analysis Results:")
                for item in result['data']:
                    print(f"  Text: {item.get('text', 'N/A')}")
                    print(f"  Sentiment: {item.get('sentiment', 'N/A')}")
                    print(f"  Confidence: {item.get('confidence', 'N/A')}")
                    print()
            else:
                print(f"❌ Analysis failed: {result['error']}")
        else:
            print(f"❌ API error: {response.status_code}")
    except Exception as e:
        print(f"❌ Request failed: {str(e)}")

if __name__ == "__main__":
    print("🧪 Flask LLM ETL API Client")
    print("=" * 50)
    print("Make sure the Flask server is running:")
    print("python flask_llm_app.py")
    print()
    
    test_flask_api()
    test_text_analysis_example()
    
    print("\n✨ API testing completed!")
    print("\n📱 You can also test the web interface at: http://localhost:5000")
