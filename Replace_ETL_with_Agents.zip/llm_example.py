import os
import pandas as pd
from etl_orchestrator import ETLOrchestrator

def llm_transformation_example():
    """Example using LLM for data transformation"""
    
    # Create sample data
    sample_data = {
        'product_description': [
            'High-quality laptop with 16GB RAM and 512GB SSD',
            'Wireless mouse with ergonomic design',
            'Mechanical keyboard with RGB lighting',
            '4K monitor with HDR support'
        ],
        'price': [999.99, 29.99, 79.99, 449.99],
        'category': ['Electronics', 'Electronics', 'Electronics', 'Electronics']
    }
    
    df = pd.DataFrame(sample_data)
    df.to_csv('products.csv', index=False)
    print("✅ Created products.csv")
    
    # Initialize orchestrator with LLM support
    # Note: You need to set OPENAI_API_KEY environment variable
    orchestrator = ETLOrchestrator()
    
    # Update the transformer to include LLM capabilities
    from data_transformation_agent import DataTransformationAgent
    orchestrator.transformer = DataTransformationAgent(
        llm_api_key=os.getenv("OPENAI_API_KEY"),
        llm_provider="openai",
        llm_model="gpt-3.5-turbo"
    )
    
    # LLM-based transformation configuration
    config = {
        "name": "llm_product_pipeline",
        "description": "Transform product data using LLM",
        "input": {
            "files": ["products.csv"],
            "batch": False,
            "params": {"encoding": "utf-8"}
        },
        "transformations": [
            {
                "type": "llm",
                "params": {
                    "prompt": """
                    Analyze the product descriptions and extract the following information for each product:
                    1. Main product type (e.g., "laptop", "mouse", "keyboard", "monitor")
                    2. Key features (list of main features)
                    3. Target audience (e.g., "professionals", "gamers", "general users")
                    4. Quality level (e.g., "premium", "mid-range", "budget")
                    
                    Return the result as a JSON array with objects containing these fields.
                    """,
                    "temperature": 0.3,
                    "max_tokens": 1500
                }
            }
        ],
        "output": {
            "path": "output/llm_enhanced_products.json",
            "format": "json",
            "params": {}
        }
    }
    
    # Run pipeline
    print("\n🤖 Running LLM Transformation Pipeline...")
    result = orchestrator.run_pipeline(config)
    
    if result['success']:
        print(f"✅ LLM pipeline completed successfully!")
        print(f"📊 Records processed: {result['pipeline_record']['records_processed']}")
        print(f"⏱️  Execution time: {result['execution_time']:.2f} seconds")
        
        output_path = result['output_results'].get('output_path', 'No output file generated')
        print(f"📁 Output saved to: {output_path}")
        
        # Show original vs transformed data
        print("\n📥 Original data:")
        print(df[['product_description', 'price']].head())
        
        print("\n🤖 LLM-transformed data:")
        if os.path.exists(output_path):
            import json
            with open(output_path, 'r') as f:
                transformed_data = json.load(f)
            for i, item in enumerate(transformed_data[:2]):
                print(f"Product {i+1}: {item}")
        
    else:
        print(f"❌ LLM pipeline failed: {result['error']}")

def sentiment_analysis_example():
    """Example using LLM for sentiment analysis"""
    
    # Create sample customer feedback data
    feedback_data = {
        'customer_id': [1, 2, 3, 4, 5],
        'feedback': [
            'This product is amazing! Works perfectly and exceeded my expectations.',
            'Terrible experience. The product broke after one week.',
            'It\'s okay, does what it\'s supposed to do but nothing special.',
            'Outstanding quality! Best purchase I\'ve made this year.',
            'Poor customer service and the product doesn\'t match the description.'
        ],
        'rating': [5, 1, 3, 5, 2]
    }
    
    df = pd.DataFrame(feedback_data)
    df.to_csv('customer_feedback.csv', index=False)
    print("✅ Created customer_feedback.csv")
    
    # Initialize orchestrator
    orchestrator = ETLOrchestrator()
    
    # Update transformer with LLM
    from data_transformation_agent import DataTransformationAgent
    orchestrator.transformer = DataTransformationAgent(
        llm_api_key=os.getenv("OPENAI_API_KEY"),
        llm_provider="openai",
        llm_model="gpt-3.5-turbo"
    )
    
    # Sentiment analysis configuration
    config = {
        "name": "sentiment_analysis_pipeline",
        "description": "Analyze customer feedback sentiment using LLM",
        "input": {
            "files": ["customer_feedback.csv"],
            "batch": False,
            "params": {"encoding": "utf-8"}
        },
        "transformations": [
            {
                "type": "llm",
                "params": {
                    "prompt": """
                    Analyze the customer feedback and determine:
                    1. Sentiment (positive, negative, neutral)
                    2. Emotion (satisfied, frustrated, disappointed, excited, etc.)
                    3. Key topics mentioned (e.g., quality, price, service, durability)
                    4. Urgency level (high, medium, low) - how quickly this needs attention
                    
                    Return the result as a JSON array where each object corresponds to a feedback entry
                    and contains the original feedback plus the analysis results.
                    """,
                    "temperature": 0.2,
                    "max_tokens": 2000
                }
            }
        ],
        "output": {
            "path": "output/sentiment_analysis.json",
            "format": "json",
            "params": {}
        }
    }
    
    # Run pipeline
    print("\n💭 Running Sentiment Analysis Pipeline...")
    result = orchestrator.run_pipeline(config)
    
    if result['success']:
        print(f"✅ Sentiment analysis completed!")
        print(f"📊 Feedback entries analyzed: {result['pipeline_record']['records_processed']}")
        
        output_path = result['output_results'].get('output_path', 'No output file generated')
        print(f"📁 Results saved to: {output_path}")
        
        # Show sample results
        if os.path.exists(output_path):
            import json
            with open(output_path, 'r') as f:
                analysis_results = json.load(f)
            print("\n💭 Sample sentiment analysis:")
            for i, result in enumerate(analysis_results[:2]):
                print(f"Feedback {i+1}:")
                print(f"  Original: {result.get('feedback', 'N/A')}")
                print(f"  Sentiment: {result.get('sentiment', 'N/A')}")
                print(f"  Emotion: {result.get('emotion', 'N/A')}")
                print()
        
    else:
        print(f"❌ Sentiment analysis failed: {result['error']}")

if __name__ == "__main__":
    print("🤖 LLM-Powered ETL Examples")
    print("=" * 50)
    
    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  WARNING: OPENAI_API_KEY environment variable not set!")
        print("Please set your OpenAI API key to run LLM examples:")
        print("export OPENAI_API_KEY='your-api-key-here'")
        print()
    
    # Create output directory
    os.makedirs('output', exist_ok=True)
    
    # Run examples
    try:
        llm_transformation_example()
        sentiment_analysis_example()
        print("\n✨ LLM examples completed!")
    except Exception as e:
        print(f"\n❌ Error running LLM examples: {str(e)}")
        print("Make sure you have a valid OpenAI API key set.")
