from config import GOOGLE_API_KEY, LLM_PROVIDER, LLM_MODEL
from etl_orchestrator import ETLOrchestrator

def test_config_api_key():
    """Test API key from configuration file"""
    
    print("Configuration File Test")
    print("=" * 30)
    print(f"Provider: {LLM_PROVIDER}")
    print(f"Model: {LLM_MODEL}")
    print(f"API Key: {'Configured' if GOOGLE_API_KEY else 'Not configured'}")
    
    if not GOOGLE_API_KEY:
        print("ERROR: No API key in config file")
        return
    
    # Test data
    test_data = [
        {"text": "I love this product!", "id": 1},
        {"text": "This is terrible", "id": 2}
    ]
    
    try:
        # Create orchestrator with config
        orchestrator = ETLOrchestrator(google_api_key=GOOGLE_API_KEY)
        
        # Simple transformation
        transformations = [{
            'type': 'llm',
            'params': {
                'prompt': 'Analyze sentiment (positive/negative) for each text. Return as JSON.',
                'temperature': 0.1,
                'max_tokens': 100
            }
        }]
        
        print("Testing API key...")
        result = orchestrator.transformer.transform(test_data, transformations)
        
        if result['success']:
            print("SUCCESS: API key is working!")
            print("Results:")
            for item in result['data']:
                print(f"  {item}")
        else:
            print(f"FAILED: {result['error']}")
            
    except Exception as e:
        print(f"ERROR: {str(e)}")

if __name__ == "__main__":
    test_config_api_key()
