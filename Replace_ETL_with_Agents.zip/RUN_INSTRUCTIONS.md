# Developer - ETL Module: Run Instructions

## 🚀 Quick Start Guide

### Prerequisites
- Python 3.8 or higher
- Google API Key (for LLM features)

## 📋 Step-by-Step Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure API Key (Optional but Recommended)
Edit `config.py` and add your Google API key:
```python
GOOGLE_API_KEY = "your-google-api-key-here"
```

### 3. Choose Your Running Method

## Method 1: Basic ETL (No API Key Required)
```bash
python simple_example.py
```
**What it does:**
- Reads sample CSV data
- Applies basic transformations (trim, remove duplicates, convert types)
- Saves processed data to `output/processed_employees.csv`

## Method 2: Web Interface (Recommended)
```bash
python flask_llm_app.py
```
**Then open your browser and go to:**
```
http://localhost:5000
```
**Features:**
- Interactive web interface
- File upload support
- Real-time LLM transformations
- API key management

## Method 3: Configuration-Based Examples
```bash
python config_example.py
```
**What it does:**
- Uses configuration file for API key
- Demonstrates product analysis with LLM
- Shows enhanced data transformations

## Method 4: API Key Testing
```bash
python simple_config_test.py
```
**What it does:**
- Tests your Google API key
- Validates LLM connectivity
- Shows sample transformation

## 🎯 Choose Your Use Case:

### For Quick Testing:
```bash
python simple_example.py
```

### For Web Interface:
```bash
python flask_llm_app.py
# Then visit http://localhost:5000
```

### For LLM Features:
```bash
python config_example.py
```

### For API Validation:
```bash
python simple_config_test.py
```

## 📊 Expected Results:

### Basic ETL Output:
- Creates `output/processed_employees.csv`
- Processes 4 employee records
- Removes duplicates and cleans data

### Web Interface:
- Interactive form at http://localhost:5000
- CSV data input with automatic parsing
- File upload capabilities
- Real-time transformation results
- API key management

### LLM Transformations:
- Enhanced data with AI-generated fields
- Name-email concatenation
- Custom prompt-based transformations

## 🔧 Troubleshooting:

### If you get "ModuleNotFoundError":
```bash
pip install -r requirements.txt
```

### If LLM features don't work:
1. Check your Google API key in `config.py`
2. Verify API key is valid and has Gemini access
3. Check quota limits at https://ai.dev/usage

### If Flask server doesn't start:
1. Check if port 5000 is available
2. Try a different port: `python flask_llm_app.py --port 5001`

### If files aren't found:
1. Make sure you're in the correct directory
2. Check file paths in your configuration

## 📁 Generated Files:
- `output/` - Contains all processed results
- `sample_data.csv` - Created by examples (if needed)
- Log output in console

## 🎉 Success Indicators:
- ✅ No import errors
- ✅ Server starts successfully
- ✅ Web interface loads at http://localhost:5000
- ✅ Output files created in `output/` directory
- ✅ API key test passes (for LLM features)

## 📚 Additional Resources:
- Full documentation: `README.md`
- Configuration options: `config.py`
- API endpoints: http://localhost:5000/health
- Example configurations: Various `.py` files

## 🆘 Need Help?
1. Check the console output for error messages
2. Verify your Python environment
3. Test with basic examples first
4. Check API key configuration for LLM features
