from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd


def add_rank_by_salary(df: pd.DataFrame, salary_column: str | None = None) -> pd.DataFrame:
    out = df.copy()
    salary_col = None

    if salary_column:
        if salary_column not in out.columns:
            raise ValueError(f"Specified salary column '{salary_column}' not found in CSV.")
        salary_col = salary_column
    else:
        for col in out.columns:
            if col.strip().lower() == "salary":
                salary_col = col
                break

    if salary_col is None:
        raise ValueError("Salary column not found. Provide --salary-column or ensure a column named 'salary' exists.")

    series = pd.to_numeric(out[salary_col], errors="coerce")
    if series.isna().all():
        raise ValueError(f"Salary column '{salary_col}' contains no numeric data.")

    out["Rank"] = series.rank(method="min", ascending=False).astype("Int64")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Add Rank column based on salary (highest salary = rank 1).")
    parser.add_argument("input_csv", type=Path, help="Input CSV file path.")
    parser.add_argument("-o", "--output", type=Path, help="Output CSV file path (default: overwrite input).")
    parser.add_argument("-s", "--salary-column", help="Exact name of salary column (optional; defaults to case-insensitive 'salary').")
    args = parser.parse_args()

    if not args.input_csv.exists():
        sys.exit(f"Error: Input file not found: {args.input_csv}")

    try:
        df = pd.read_csv(args.input_csv)
    except Exception as e:
        sys.exit(f"Error reading CSV: {e}")

    try:
        ranked = add_rank_by_salary(df, salary_column=args.salary_column)
    except Exception as e:
        sys.exit(f"Error processing data: {e}")

    output_path = args.output or args.input_csv
    try:
        ranked.to_csv(output_path, index=False)
        print(f"Wrote ranked output to: {output_path}")
    except Exception as e:
        sys.exit(f"Error writing CSV: {e}")


if __name__ == "__main__":
    main()
