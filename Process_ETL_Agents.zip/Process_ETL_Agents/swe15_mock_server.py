# swe15_mock_server.py
from http.server import HTTPServer, BaseHTTPRequestHandler
import json

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/generate":
            content_len = int(self.headers["Content-Length"])
            post_data = self.rfile.read(content_len)
            body = json.loads(post_data)
            prompt = body.get("prompt", "")
            # Simple mock: echo prompt into a basic transform
            response_text = f"""from __future__ import annotations

import pandas as pd

def transform(df: pd.DataFrame) -> pd.DataFrame:
    # User request: {prompt}
    out = df.copy()
    # TODO: implement real logic based on prompt
    return out
"""
            # Include prompt in response so UI sees uniqueness
            response_obj = {"response": response_text, "prompt": prompt}
            print(f"[DEBUG] Mock responding with: {response_obj}")
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(response_obj).encode())
        else:
            self.send_error(404)

if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8000), Handler).serve_forever()
