import os

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "AIzaSyBaTYo84ZeR41hsI6vDxBKvjfgTFFMvZ_g")

LLM_PROVIDER = "google"
LLM_MODEL = "gemini-2.0-flash"
DEFAULT_TEMPERATURE = 0.3
DEFAULT_MAX_TOKENS = 10000

# SWE-1.5 configuration (alternative to Gemini)
SWE15_ENDPOINT = os.getenv("SWE15_ENDPOINT", "http://127.0.0.1:8000/generate")
