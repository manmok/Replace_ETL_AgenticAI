# Process_ETL_Agents

## Folders

- Input: `D:\Windsurf\Process_ETL_Agents\Input` (place one or more `*.csv` files here)
- Intermediate temp: `D:\Windsurf\Process_ETL_Agents\Intermediate_Temp` (pipeline writes intermediate `cleanse.csv` / `transform.csv`)
- Output: `D:\Windsurf\Process_ETL_Agents\Output\Output.csv`

## Config

Gemini keys/model are loaded from:

- `D:\Windsurf\Process_ETL_Agents\Output\Config.py`

You can also override the API key by setting the environment variable `GOOGLE_API_KEY`.

## Install

```bash
pip install -r requirements.txt
```

## Run Flask UI

```bash
python run_webapp.py
```

Then open:

- `http://127.0.0.1:5000`

## How it works

- Cleanse agent: `etl/agents/cleanse_agent.py`
- Transform agent (generated): `etl/agents/generated_transform.py`
- Transform agent loader: `etl/agents/transform_agent.py`
- Pipeline: `etl/pipeline.py`

From the UI:

- Generate/Update Transform Agent: updates `generated_transform.py` using Gemini based on your prompt
- Sample Output: shows the first 10 rows after Cleanse + Transform
- Run ETL: writes `Output/Output.csv`
