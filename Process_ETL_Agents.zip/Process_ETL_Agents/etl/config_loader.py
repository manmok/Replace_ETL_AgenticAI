from __future__ import annotations

import importlib.util
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class LlmConfig:
    google_api_key: str
    model: str
    temperature: float
    swe15_endpoint: str


def load_llm_config() -> LlmConfig:
    base_dir = Path(r"D:\Windsurf\Process_ETL_Agents")
    cfg_path = base_dir / "Output" / "Config.py"

    if not cfg_path.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_path}")

    spec = importlib.util.spec_from_file_location("etl_output_config", str(cfg_path))
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load config module")

    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    api_key = getattr(mod, "GOOGLE_API_KEY", "")
    model = getattr(mod, "LLM_MODEL", "gemini-2.0-flash")
    temperature = float(getattr(mod, "DEFAULT_TEMPERATURE", 0.3))
    swe15_endpoint = getattr(mod, "SWE15_ENDPOINT", "http://127.0.0.1:8000/generate")

    if not api_key:
        raise ValueError("GOOGLE_API_KEY is missing/empty in Output/Config.py")

    return LlmConfig(google_api_key=api_key, model=model, temperature=temperature, swe15_endpoint=swe15_endpoint)
