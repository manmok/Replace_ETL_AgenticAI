from __future__ import annotations

import re
from typing import Optional


def _extract_python_code_block(text: str) -> str:
    fenced = re.findall(r"```(?:python)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        return fenced[0].strip() + "\n"
    return text.strip() + "\n"


def generate_transform_code(
    *,
    api_key: str,
    model: str,
    user_prompt: str,
    existing_code: Optional[str] = None,
    temperature: float = 0.3,
) -> tuple[str, str]:
    try:
        import google.generativeai as genai
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "Missing dependency 'google-generativeai'. Install dependencies with: py -m pip install -r requirements.txt"
        ) from e

    genai.configure(api_key=api_key)
    m = genai.GenerativeModel(model)

    system_instructions = (
        "You are generating ONLY Python code for a file named generated_transform.py.\n"
        "You MUST output a complete, valid Python module.\n"
        "The file MUST define: transform(df: pandas.DataFrame) -> pandas.DataFrame\n"
        "Requirements:\n"
        "- Import pandas as pd\n"
        "- Do not read/write files\n"
        "- Do not use external network calls\n"
        "- Return a pandas DataFrame\n"
        "- Preserve all columns unless user explicitly requests dropping\n"
        "- Be robust to missing columns (if a column doesn't exist, skip that operation)\n"
        "- Prefer non-destructive edits and keep the code simple and readable\n"
    )

    existing_section = ""
    if existing_code and existing_code.strip():
        existing_section = (
            "\nCurrent generated_transform.py (modify/enhance this code based on the user request):\n"
            "```python\n"
            + existing_code.strip()
            + "\n```\n"
        )

    prompt = (
        system_instructions
        + existing_section
        + "\nUser request:\n"
        + user_prompt.strip()
        + "\n\nOutput ONLY the Python code for the updated generated_transform.py module."
    )

    resp = m.generate_content(
        prompt,
        generation_config={
            "temperature": temperature,
        },
    )

    text = getattr(resp, "text", None) or ""
    code = _extract_python_code_block(text)

    if "def transform" not in code:
        code = "from __future__ import annotations\n\nimport pandas as pd\n\n\n" + code
        if "def transform" not in code:
            code += "\n\n\ndef transform(df: pd.DataFrame) -> pd.DataFrame:\n    return df\n"

    return code, text
