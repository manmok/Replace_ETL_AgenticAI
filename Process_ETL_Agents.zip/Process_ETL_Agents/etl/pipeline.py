from __future__ import annotations

import glob
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

import pandas as pd

from .agents.base import AgentContext, DataAgent
from .agents.cleanse_agent import CleanseAgent
from .agents.transform_agent import TransformAgent
from .paths import INPUT_DIR, OUTPUT_DIR, OUTPUT_FILE, TEMP_DIR


@dataclass(frozen=True)
class PipelineResult:
    input_files: List[str]
    output_file: str
    row_count: int


def _ensure_dirs() -> None:
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def _read_csv_files(files: Iterable[str]) -> pd.DataFrame:
    frames: List[pd.DataFrame] = []
    for fp in files:
        frames.append(pd.read_csv(fp))
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def run_pipeline() -> PipelineResult:
    _ensure_dirs()

    files = sorted(glob.glob(str(INPUT_DIR / "*.csv")))
    df = _read_csv_files(files)

    ctx = AgentContext(temp_dir=str(TEMP_DIR))
    agents: List[DataAgent] = [CleanseAgent(), TransformAgent()]

    current = df
    for agent in agents:
        current = agent.run(current, ctx)
        temp_path = Path(TEMP_DIR) / f"{agent.name}.csv"
        current.to_csv(temp_path, index=False)

    current.to_csv(OUTPUT_FILE, index=False)
    return PipelineResult(input_files=files, output_file=str(OUTPUT_FILE), row_count=len(current))


def sample_preview(n: int = 10) -> pd.DataFrame:
    _ensure_dirs()
    files = sorted(glob.glob(str(INPUT_DIR / "*.csv")))
    df = _read_csv_files(files)
    if df.empty:
        return df

    ctx = AgentContext(temp_dir=str(TEMP_DIR))
    current = CleanseAgent().run(df, ctx)
    current = current.head(n)
    current = TransformAgent().run(current, ctx)
    return current


def sample_raw_input(n: int = 10) -> pd.DataFrame:
    _ensure_dirs()
    files = sorted(glob.glob(str(INPUT_DIR / "*.csv")))
    df = _read_csv_files(files)
    if df.empty:
        return df
    return df.head(n)


def sample_cleanse_only(n: int = 10) -> pd.DataFrame:
    _ensure_dirs()
    files = sorted(glob.glob(str(INPUT_DIR / "*.csv")))
    df = _read_csv_files(files)
    if df.empty:
        return df

    ctx = AgentContext(temp_dir=str(TEMP_DIR))
    current = CleanseAgent().run(df, ctx)
    return current.head(n)
