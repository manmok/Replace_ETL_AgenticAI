from __future__ import annotations

from pathlib import Path


BASE_DIR = Path(r"D:\Windsurf\Process_ETL_Agents")
INPUT_DIR = BASE_DIR / "Input"
TEMP_DIR = BASE_DIR / "Intermediate_Temp"
OUTPUT_DIR = BASE_DIR / "Output"
OUTPUT_FILE = OUTPUT_DIR / "Output.csv"
