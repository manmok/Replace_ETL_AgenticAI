from __future__ import annotations

import importlib
import traceback
from pathlib import Path
from datetime import datetime
from types import ModuleType
from typing import Callable, Tuple

import pandas as pd

from .base import AgentContext


def _load_generated_module() -> ModuleType:
    module = importlib.import_module("etl.agents.generated_transform")
    return importlib.reload(module)


def validate_generated_transform(mod: ModuleType) -> Tuple[bool, str]:
    fn = getattr(mod, "transform", None)
    if fn is None or not callable(fn):
        return False, "Generated module must define a callable function named 'transform(df: pd.DataFrame) -> pd.DataFrame'."
    return True, ""


def apply_transform(df: pd.DataFrame) -> pd.DataFrame:
    mod = _load_generated_module()
    ok, msg = validate_generated_transform(mod)
    if not ok:
        raise ValueError(msg)
    fn: Callable[[pd.DataFrame], pd.DataFrame] = getattr(mod, "transform")
    return fn(df)


class TransformAgent:
    name = "transform"

    def run(self, df: pd.DataFrame, ctx: AgentContext) -> pd.DataFrame:
        return apply_transform(df)


def update_generated_transform_code(repo_root: Path, new_code: str) -> None:
    target = repo_root / "etl" / "agents" / "generated_transform.py"
    target.write_text(new_code, encoding="utf-8")


def read_generated_transform_code(repo_root: Path) -> str:
    target = repo_root / "etl" / "agents" / "generated_transform.py"
    if not target.exists():
        return ""
    return target.read_text(encoding="utf-8")


def backup_generated_transform_code(repo_root: Path, temp_dir: Path) -> str | None:
    target = repo_root / "etl" / "agents" / "generated_transform.py"
    if not target.exists():
        return None

    temp_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = temp_dir / f"generated_transform_{ts}.py"
    backup_path.write_text(target.read_text(encoding="utf-8"), encoding="utf-8")
    return str(backup_path)


def safe_apply_transform(df: pd.DataFrame) -> Tuple[pd.DataFrame | None, str | None]:
    try:
        return apply_transform(df), None
    except Exception:
        return None, traceback.format_exc()
