from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import pandas as pd


@dataclass(frozen=True)
class AgentContext:
    temp_dir: str


class DataAgent(Protocol):
    name: str

    def run(self, df: pd.DataFrame, ctx: AgentContext) -> pd.DataFrame: ...
