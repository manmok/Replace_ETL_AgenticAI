from __future__ import annotations

import pandas as pd

from .base import AgentContext


class CleanseAgent:
    name = "cleanse"

    def run(self, df: pd.DataFrame, ctx: AgentContext) -> pd.DataFrame:
        cleaned = df.copy()
        cleaned.columns = [str(c).strip() for c in cleaned.columns]

        for col in cleaned.columns:
            if pd.api.types.is_object_dtype(cleaned[col].dtype):
                cleaned[col] = cleaned[col].astype("string")
                cleaned[col] = cleaned[col].str.strip()
                cleaned[col] = cleaned[col].replace({"": pd.NA, "nan": pd.NA, "None": pd.NA})

        cleaned = cleaned.drop_duplicates()
        return cleaned
