from __future__ import annotations

import pandas as pd

def transform(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    # Trim all string columns
    for c in out.columns:
        if out[c].dtype == "object":
            out[c] = out[c].astype("string").str.strip()

    # Find salary column (case-insensitive)
    salary_col = None
    for col in out.columns:
        if col.strip().lower() == "salary":
            salary_col = col
            break
    if salary_col is None:
        raise ValueError("Salary column not found. Ensure a column named 'salary' exists.")

    # Convert to numeric, rank descending (highest salary = rank 1)
    series = pd.to_numeric(out[salary_col], errors="coerce")
    if series.isna().all():
        raise ValueError(f"Salary column '{salary_col}' contains no numeric data.")
    out["Rank"] = series.rank(method="min", ascending=False).astype("Int64")
    return out