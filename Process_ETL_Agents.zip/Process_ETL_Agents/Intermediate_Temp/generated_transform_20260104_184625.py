from __future__ import annotations

import pandas as pd

def transform(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    # Example: trim all string columns
    for c in out.columns:
        if out[c].dtype == "object":
            out[c] = out[c].astype("string").str.strip()
    return out