from __future__ import annotations

import pandas as pd


def transform(df: pd.DataFrame) -> pd.DataFrame:
    return df
