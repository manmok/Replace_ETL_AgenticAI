async function apiGet(url){
  const res = await fetch(url);
  let data;
  try {
    data = await res.json();
  } catch {
    data = {error: await res.text()};
  }
  return {ok: res.ok, status: res.status, data};
}

async function apiPost(url, body){
  const res = await fetch(url, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(body)
  });
  let data;
  try {
    data = await res.json();
  } catch {
    data = {error: await res.text()};
  }
  return {ok: res.ok, status: res.status, data};
}

function setStatus(msg){
  document.getElementById('status').textContent = msg || '';
}

function renderTable(columns, rows){
  if(!rows || rows.length === 0){
    return '<div class="muted" style="padding:10px">No rows to display. Add CSV files to Input folder.</div>';
  }
  const cols = columns && columns.length ? columns : Object.keys(rows[0] || {});
  let html = '<table><thead><tr>';
  for(const c of cols){ html += `<th>${escapeHtml(String(c))}</th>`; }
  html += '</tr></thead><tbody>';
  for(const r of rows){
    html += '<tr>';
    for(const c of cols){
      html += `<td>${escapeHtml(String(r[c] ?? ''))}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table>';
  return html;
}

function escapeHtml(s){
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

async function loadSample(){
  setStatus('Loading sample...');
  document.getElementById('error').textContent = '';
  const {ok, data, status} = await apiGet('/api/sample?n=10');
  if(!ok){
    setStatus(`Failed to load sample (HTTP ${status})`);
    document.getElementById('error').textContent = (data && (data.error || data.hint)) || JSON.stringify(data,null,2);
    return;
  }
  setStatus(`Loaded ${data.row_count} rows (preview).`);
  document.getElementById('tableWrap').innerHTML = renderTable(data.columns, data.rows);
}

async function loadInput(){
  setStatus('Loading raw input...');
  document.getElementById('error').textContent = '';
  const {ok, data, status} = await apiGet('/api/sample_input?n=10');
  if(!ok){
    setStatus(`Failed to load raw input (HTTP ${status})`);
    document.getElementById('error').textContent = (data && (data.error || data.hint)) || JSON.stringify(data,null,2);
    return;
  }
  setStatus(`Loaded ${data.row_count} raw input rows.`);
  document.getElementById('tableWrap').innerHTML = renderTable(data.columns, data.rows);
}

async function generate(){
  const mode = document.querySelector('input[name="mode"]:checked')?.value || 'gemini';
  const prompt = document.getElementById('prompt').value;
  const manualCode = document.getElementById('manualCode')?.value || '';
  const model = document.getElementById('modelSelect')?.value || 'gemini';
  console.log('[DEBUG] mode:', mode, 'model:', model, 'prompt:', prompt);

  if(mode === 'manual'){
    setStatus('Saving manual transform code...');
  } else {
    setStatus(`Generating transform code via ${model.toUpperCase()}...`);
  }
  document.getElementById('error').textContent = '';

  const endpoint = mode === 'manual' ? '/api/update_transform_manual' : '/api/generate_transform';
  const payload = mode === 'manual' ? {code: manualCode} : {prompt, model};
  console.log('[DEBUG] endpoint:', endpoint, 'payload:', payload);
  const {ok, data, status} = await apiPost(endpoint, payload);
  console.log('[DEBUG] response status:', status, 'data:', data);
  if(!ok){
    setStatus(`Generation failed (HTTP ${status})`);
    const msg = (data && (data.error || data.hint)) || JSON.stringify(data,null,2);
    const details = data && data.details ? `\n\n${data.details}` : '';
    document.getElementById('error').textContent = msg + details;
    return;
  }

  document.getElementById('code').textContent = data.generated_code || '';

  setStatus('Transform updated successfully. Click "Load Sample Preview" to see transformed output.');
}

async function runEtl(){
  setStatus('Running ETL...');
  document.getElementById('runResult').textContent = '';
  const {ok, data, status} = await apiPost('/api/run_etl', {});
  if(!ok){
    setStatus(`ETL failed (HTTP ${status})`);
    document.getElementById('runResult').textContent = (data && (data.error || data.hint)) || JSON.stringify(data,null,2);
    return;
  }
  setStatus('ETL complete');
  document.getElementById('runResult').textContent = JSON.stringify(data, null, 2);
}

document.getElementById('btnGenerate').addEventListener('click', generate);
document.getElementById('btnLoadSample').addEventListener('click', loadSample);
document.getElementById('btnLoadInput').addEventListener('click', loadInput);
document.getElementById('btnRun').addEventListener('click', runEtl);

function syncModeUI(){
  const mode = document.querySelector('input[name="mode"]:checked')?.value || 'gemini';
  const geminiBox = document.getElementById('geminiBox');
  const manualBox = document.getElementById('manualBox');
  if(geminiBox && manualBox){
    geminiBox.style.display = mode === 'gemini' ? '' : 'none';
    manualBox.style.display = mode === 'manual' ? '' : 'none';
  }
  // Ensure model dropdown reflects current selection
  const modelSelect = document.getElementById('modelSelect');
  if(modelSelect){
    modelSelect.value = mode === 'gemini' ? 'gemini' : 'swe15';
  }
}

for(const el of document.querySelectorAll('input[name="mode"]')){
  el.addEventListener('change', syncModeUI);
}
syncModeUI();

loadSample();
