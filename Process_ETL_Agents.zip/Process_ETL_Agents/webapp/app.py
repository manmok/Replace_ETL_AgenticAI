from __future__ import annotations

from pathlib import Path

from flask import Flask, jsonify, render_template, request

from etl.config_loader import load_llm_config
from etl.llm.gemini_client import generate_transform_code
from etl.llm.swe15_client import generate_transform_code_swe15
from etl.agents.transform_agent import (
    backup_generated_transform_code,
    read_generated_transform_code,
    safe_apply_transform,
    update_generated_transform_code,
)
from etl.pipeline import run_pipeline, sample_cleanse_only, sample_preview, sample_raw_input


BASE_DIR = Path(r"D:\Windsurf\Process_ETL_Agents")


def create_app() -> Flask:
    app = Flask(__name__, template_folder=str(BASE_DIR / "webapp" / "templates"), static_folder=str(BASE_DIR / "webapp" / "static"))

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/sample")
    def api_sample():
        n = int(request.args.get("n", "10"))
        df = sample_preview(n=n)
        return jsonify({
            "rows": df.fillna("").to_dict(orient="records"),
            "columns": list(df.columns),
            "row_count": int(len(df)),
        })

    @app.get("/api/sample_input")
    def api_sample_input():
        n = int(request.args.get("n", "10"))
        df = sample_raw_input(n=n)
        return jsonify({
            "rows": df.fillna("").to_dict(orient="records"),
            "columns": list(df.columns),
            "row_count": int(len(df)),
        })

    @app.post("/api/generate_transform")
    def api_generate_transform():
        print("[DEBUG] /api/generate_transform called")
        body = request.get_json(force=True)
        print(f"[DEBUG] request body: {body}")
        user_prompt = (body.get("prompt") or "").strip()
        model = (body.get("model") or "").strip().lower()
        print(f"[DEBUG] extracted prompt: '{user_prompt}', model: '{model}'")
        if not user_prompt:
            print("[DEBUG] rejecting: prompt empty")
            return jsonify({"error": "Prompt is required"}), 400

        try:
            cfg = load_llm_config()
            existing_code = read_generated_transform_code(BASE_DIR)
            if model == "swe15":
                print(f"[DEBUG] Using SWE-1.5 at: {cfg.swe15_endpoint}")
                print(f"[DEBUG] Prompt: {user_prompt}")
                code, raw = generate_transform_code_swe15(
                    endpoint=cfg.swe15_endpoint,
                    user_prompt=user_prompt,
                    existing_code=existing_code,
                )
                print(f"[DEBUG] SWE-1.5 raw response: {raw}")
                # For SWE-1.5, return the mock response directly without updating the file
                return jsonify({
                    "generated_code": code,
                    "raw_output": raw,
                })
            else:
                print(f"[DEBUG] Using Gemini with model: {cfg.model}")
                code, raw = generate_transform_code(
                    api_key=cfg.google_api_key,
                    model=cfg.model,
                    temperature=cfg.temperature,
                    user_prompt=user_prompt,
                    existing_code=existing_code,
                )
            backup_path = backup_generated_transform_code(BASE_DIR, BASE_DIR / "Intermediate_Temp")
            update_generated_transform_code(BASE_DIR, code)

            print(f"[DEBUG] Code to return: {code}")
            return jsonify({
                "generated_code": code,
                "raw_output": raw,
                "backup_file": backup_path,
            })
        except Exception as e:
            import traceback
            msg = str(e)
            status = 500
            if "quota" in msg.lower() or "resourceexhausted" in msg.lower() or "429" in msg:
                status = 429
            return jsonify({
                "error": msg,
                "details": traceback.format_exc(),
                "hint": "Gemini API quota/billing may be required. Check https://ai.google.dev/gemini-api/docs/rate-limits and your usage/billing.",
            }), status

    @app.post("/api/run_etl")
    def api_run_etl():
        res = run_pipeline()
        return jsonify({
            "input_files": res.input_files,
            "output_file": res.output_file,
            "row_count": res.row_count,
        })

    @app.post("/api/update_transform_manual")
    def api_update_transform_manual():
        body = request.get_json(force=True)
        code = (body.get("code") or "").strip()
        if not code:
            return jsonify({"error": "Manual code is required"}), 400

        temp_dir = BASE_DIR / "Intermediate_Temp"
        backup_path = backup_generated_transform_code(BASE_DIR, temp_dir)

        update_generated_transform_code(BASE_DIR, code)

        return jsonify({
            "generated_code": code,
            "backup_file": backup_path,
        })

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True)
